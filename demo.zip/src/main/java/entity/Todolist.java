package entity;

import javax.persistence.*;

@Entity
//@Table(name = "todolist", schema = "testdb", catalog = "")
public class Todolist {
    @Basic
    @Column(name = "toDoItems")
    private String toDoItems;
    @Id
    private Long id;

    public String getToDoItems() {
        return toDoItems;
    }

    public void setToDoItems(String toDoItems) {
        this.toDoItems = toDoItems;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Todolist todolist = (Todolist) o;

        if (toDoItems != null ? !toDoItems.equals(todolist.toDoItems) : todolist.toDoItems != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return toDoItems != null ? toDoItems.hashCode() : 0;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }
}
