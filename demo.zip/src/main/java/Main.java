import entity.Todolist;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;
import javax.persistence.*;

public class Main {
    static ArrayList<String> toDoItems = new ArrayList<String>();
    static Scanner getUserInput = new Scanner(System.in);

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("default");
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try{
            et.begin();
            Todolist tle1 = new Todolist();
            Todolist tle2 = new Todolist();
            Todolist tle3 = new Todolist();

        // Default To Do Items
        toDoItems.add("Get groceries");
        toDoItems.add("Wash the car");

        System.out.println("Welcome to the To-Do-List");
        System.out.println("Enter 'A' to add an item to the list, 'D' to delete an item from the list, and 'V' to view the list");

        for(int i = 0; i < 3; i++) {
            System.out.println("Enter a command: ");
            String userCommand = getUserInput.nextLine();
            if (Objects.equals(userCommand, "A") || Objects.equals(userCommand, "a")) {
                addItem();

            } else if (Objects.equals(userCommand, "D") || Objects.equals(userCommand, "d")) {
                deleteItem();

            } else if (Objects.equals(userCommand, "V") || Objects.equals(userCommand, "v")) {
                viewItem();

            } else {
                System.out.println("Not a valid command");
            }

            System.out.println("----------------------------------");
        }


            tle1.setId(0L);
            tle1.setToDoItems(toDoItems.get(0));
            tle2.setId(1L);
            tle2.setToDoItems(toDoItems.get(1));
            tle3.setId(2L);
            tle3.setToDoItems(toDoItems.get(2));
            em.persist(tle1);
            em.persist(tle2);
            em.persist(tle3);
            et.commit();

        } finally {
            if (et.isActive()) {
                et.rollback();
            }
            em.close();
            emf.close();
        }
    }
    public static void addItem(){
        System.out.println("Enter an item to add to the To-Do-List: ");
        String aItem = getUserInput.nextLine();
        toDoItems.add(aItem);
    }

    public static void deleteItem(){
        System.out.println("Enter an item to delete from the To-Do-List: ");
        String dItem = getUserInput.nextLine();
        if (toDoItems.contains(dItem)) {
            toDoItems.remove(dItem);
        } else {
            System.out.println("Item does not exist");
        }
    }

    public static void viewItem(){
        System.out.println("Items To-Do: ");
        for (String item : toDoItems)
            System.out.println("- " + item);
    }

}
